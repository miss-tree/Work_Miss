<template>
	<div>
		<div class="tou-bag">
			<div class="per-msg">
				<div class="msg">
					<p>员工：<span>张三</span></p>
					<p>部门：<span>电商部</span></p>
				</div>
			</div>
		</div>
		<div>
			<ul class="mui-table-view">
					<li class="mui-table-view-cell">
							<router-link class="mui-navigate-right" to='/qiandao'>
								<i class="iconfont icon-qiandao"></i> 考勤签到
							</router-link>
					</li>
					<li class="mui-table-view-cell">
						<router-link class="mui-navigate-right" to="/kaoqinList">
							<i class="iconfont icon-yidongbangong"></i>外勤记录
						</router-link>
					</li>
					<li class="mui-table-view-cell">
						<router-link  class="mui-navigate-right" to="/apply">
							<i class="iconfont icon-drxx81"></i>请假申请
						</router-link>
					</li>
				</ul>
		</div>
		<div>
			<nav class="mui-bar mui-bar-tab">
					<router-link class="mui-tab-item" to="/Home">
						<span class="mui-icon mui-icon-home"></span>
						<span class="mui-tab-label">企业管理</span>
					</router-link>
					<router-link class="mui-tab-item mui-active" to="/PersonCenter">
						<span class="mui-icon mui-icon-person"></span>
						<span class="mui-tab-label">个人中心</span>
					</router-link>
			</nav>
		</div>
	</div>
</template>

<script>
</script>

<style lang="scss">

</style>