<template>
  <div class="home">
  	<header class="mui-bar mui-bar-nav">
  			<a class="mui-action-back mui-icon mui-icon-left-nav mui-pull-left"></a>
  	    <h1 class="mui-title"><img src="../assets/logo.png" class="logo"/>泰恩康企业管理系统</h1>
  	</header>
  	<div class="bar-ge"></div>
  	<div>
		  	<ul class="mui-table-view">
					<li class="mui-table-view-cell">
						<a class="mui-navigate-right"><i class="iconfont icon-tuandui"></i> 团队协作</a>
					</li>
					<li class="mui-table-view-cell">
						<a class="mui-navigate-right"><i class="iconfont icon-shouji"></i>移动办公</a>
					</li>
					<li class="mui-table-view-cell">
						<a class="mui-navigate-right"><i class="iconfont icon-chicun-"></i>客户关系</a>
					</li>
				</ul>
  	</div>
  	<div>
			<nav class="mui-bar mui-bar-tab">
					<router-link class="mui-tab-item  mui-active" to="Home">
						<span class="mui-icon mui-icon-home"></span>
						<span class="mui-tab-label">企业管理</span>
					</router-link>
					<router-link class="mui-tab-item" to="/PersonCenter">
						<span class="mui-icon mui-icon-person"></span>
						<span class="mui-tab-label">个人中心</span>
					</router-link>
			</nav>
		</div>
  </div>
</template>
<script>
export default {

}
</script>
<style >
	/** { touch-action: pan-y; }*/ 
</style>
