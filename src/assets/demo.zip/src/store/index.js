import Vue from 'vue'
import Vuex from 'vuex'
import createLogger from 'vuex/dist/logger' /*内置的logger插件,用于作为调试使用*/

Vue.use(Vuex)
export default new Vuex.Store({
	modules: {
		common,
		user
	},
	state: {
		hTitle: "猫眼电影",
	},
	mutations: {
		setHTitle(state, payload) {
			state.hTitle = payload.hTitle;
		},
	},
	actions: {

	},
	plugins: [createLogger()]
})