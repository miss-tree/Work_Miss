import Vue from 'vue'
import Router from 'vue-router'
//首页界面
import Home from '../components/Home'
import PersonCenter from '../components/PersonCenter.vue'
import newsTable from '../components/message/newsTable.vue'
import setUp from '../components/other/setUp.vue'
//==========个人中心==========个人中心==========个人中心==========个人中心==========个人中心==========个人中心==========个人中心==========个人中心==========个人中心==========个人中心
import kaoqingDetail from '../components/center/kaoqingDetail.vue'
import qiandao from '../components/center/qiandao'
//import applyList from '../components/center/applyList.vue'
import apply from '../components/center/apply.vue'
import kaoqinList from '../components/center/kaoqinList.vue'
import writeApply from '../components/center/writeApply.vue'
import shenqingDetail from '../components/center/shenqingDetail.vue'
import piyue from '../components/center/piyue.vue'
import piyueDetail from '../components/center/piyueDetail.vue'
import example from '../components/sample/example.vue'

//===========订单部分===========订单部分===========订单部分===========订单部分===========订单部分===========订单部分===========订单部分===========订单部分===========订单部分
import myTicket from '../components/ticket/myTicket.vue'
import applyList from '../components/ticket/applyList.vue'
import applyTicket from '../components/ticket/applyTicket.vue'
import myTicketApply from '../components/ticket/myTicketApply.vue'
import applyDetail from '../components/ticket/applyDetail.vue'

import myOrder from '../components/order/myOrder.vue'
import orderAdd from '../components/order/orderAdd.vue'
import orderList from '../components/order/orderList.vue'
import orderDetail from '../components/order/orderDetail.vue'
import signList from '../components/order/signList.vue'
import signOrder from '../components/order/signOrder.vue'
//退货
import orderReturn from '../components/return/orderReturn.vue'
import readyReturn from '../components/return/readyReturn.vue'
import ticketList from '../components/return/ticketList.vue'
import ticketReturn from '../components/return/ticketReturn.vue'
import ticketDetail from '../components/return/ticketDetail.vue'
import unTicketList from '../components/return/unTicketList.vue'
import unTicketReturn from '../components/return/unTicketReturn.vue'
import unTicketDetail from '../components/return/unTicketDetail.vue'
//印章
import seal from '../components/seal/seal.vue'
import sealAdd from '../components/seal/sealAdd.vue'
//组件
import uploadpic from '../components/assembly/uploadpic.vue'	/*图片上传*/
import maps from '../components/assembly/maps.vue'

//测试页面==========测试页面==========测试页面==========测试页面==========测试页面==========测试页面==========测试页面==========测试页面==========测试页面
import alertCenter from '../components/sample/alertCenter.vue'
import alertSearch from '../components/sample/alertSearch.vue'
import code from '../components/sample/code.vue'
import alertRight from '../components/sample/alertRight.vue'
import lookimg from '../components/sample/lookimg.vue'
import alert from '../components/sample/alert.vue'
import slideTable from '../components/sample/slideTable.vue'
import index from '../components/sample/index.vue'
import picker from '../components/sample/picker.vue'
import accordion from '../components/sample/accordion.vue'
import actionsheet from '../components/sample/actionsheet.vue'
import badge from '../components/sample/badges.vue'
import buttons from '../components/sample/buttons.vue'
import numbutton from '../components/sample/buttons-with-badges.vue'
import iconbutton from '../components/sample/buttons-with-icons.vue'
import loadbutton from '../components/sample/buttons-with-loading.vue'
import card from '../components/sample/card.vue'
import checkboxs from '../components/sample/checkbox.vue'
import dialog from '../components/sample/dialog.vue'
import icons from '../components/sample/icons.vue'
import iconsLight from '../components/sample/icons-extra.vue'
import inputs from '../components/sample/input.vue'
import MediaList from '../components/sample/media-list.vue'
import numbox from '../components/sample/numbox.vue'
import slider from '../components/sample/slider-default.vue'
import sliderTable from '../components/sample/slider-table-default.vue'
import sliderTitle from '../components/sample/slider-with-title.vue'
import refresh from '../components/sample/refresh.vue'
import tabView from '../components/sample/tabView.vue'
import muiSample from '../components/sample/muiSample.vue'
import timeLine from '../components/sample/timeLine.vue'
import template from '../components/sample/template.vue'
import tableList from '../components/sample/tableList.vue'
import form from '../components/sample/form.vue'
import dateTable from '../components/sample/dateTable.vue'
import mode_table from '../components/sample/mode_table.vue'
//客户关系        
import client from '../components/client/client.vue'

//报销==========报销==========报销==========报销==========报销==========报销==========报销==========报销==========报销==========报销==========报销==========报销
import BxList from '../components/baoxiao/BxList.vue'
import travelDetail from '../components/baoxiao/travelDetail.vue'
import examTravel from '../components/baoxiao/examTravel.vue'
import formTable from '../components/baoxiao/formTable.vue'
import comBX from '../components/baoxiao/comBX.vue'
import actBX from '../components/baoxiao/actBX.vue'

//hr
import hr from '../components/hr/hr.vue'
import mianshiList from '../components/hr/mianshiList.vue'
import mianshiDetail from '../components/hr/mianshiDetail.vue'
import mianshiRecord from '../components/hr/mianshiRecord.vue'
import zhaopinManage from '../components/hr/zhaopinManage.vue'
import jobApply from '../components/hr/jobApply.vue'
import writejobApply from '../components/hr/writejobApply.vue'
import jobDetail from '../components/hr/jobDetail.vue'
import zhaopinList from '../components/hr/zhaopinList.vue'

/*=======================请假申请=======================请假申请=======================请假申请=======================请假申请=======================*/
import leave from '../components/leave/leave.vue'
import leaveAdd from '../components/leave/leaveAdd.vue'
import myLeave from '../components/leave/myLeave.vue'
import leaveDetail from '../components/leave/leaveDetail.vue'
/*=======================异动管理=======================异动管理=======================异动管理=======================异动管理=======================*/
import moveTab from '../components/move/moveTab.vue'
import writeMove from '../components/move/writeMove.vue'
import myMove from '../components/move/myMove.vue'
import moveDetail from '../components/move/moveDetail.vue'


//工资
import moneyList from '../components/money/moneyList.vue'
import moneyDetail from '../components/money/moneyDetail.vue'
Vue.use(Router)

export default new Router({
	mode: 'hash',
base: process.env.BASE_URL,
  routes: [
    {
      path:'/',
      redirect: '/Home'
    },
    {
      path:'/Home',
      component: Home
    },
//  消息
	{path:'/newsTable',component: newsTable},
	
//==========订单部分==========订单部分==========订单部分==========订单部分==========订单部分==========订单部分==========订单部分==========订单部分
//	开票
	{path:'/myTicket',component: myTicket},
	{path:'/applyList',component: applyList},
	{path:'/applyTicket',component: applyTicket},
	{path:'/myTicketApply',component: myTicketApply},
	{path:'/applyDetail',component: applyDetail},
//	订单
	{path:'/myOrder',component: myOrder,
	children:[{path:'',component: orderAdd,}]},
	{path:'/orderAdd',component: orderAdd},
	{path:'/orderList',component: orderList},
	{path:'/orderDetail',component: orderDetail},
	{path:'/signList',component: signList},
	{path:'/signOrder',component: signOrder},
//	退货	
	{path:'/orderReturn',component: orderReturn},
	{path:'/ticketList',component: ticketList},
	{path:'/ticketReturn',component: ticketReturn},
	{path:'/ticketDetail',component: ticketDetail},
	{path:'/unTicketList',component: unTicketList},
	{path:'/unTicketReturn',component: unTicketReturn},
	{path:'/readyReturn',component: readyReturn},
	{path:'/unTicketDetail',component: unTicketDetail},
//	功能组件
	{path:'/code',component: code},
	{path:'/maps',component: maps},
	{path:'/uploadpic',component: uploadpic},
//  报销
	{path:'/BxList',component: BxList,
    children:[{ path:'formTable', component: formTable}]},
	{path:'/examTravel',component: examTravel},
	{path:'/travelDetail',component: travelDetail},
	{path:'/comBX',component: comBX},
	{path:'/actBX',component: actBX},
//	印章	
	{path:'/seal',component: seal},
	{path:'/sealAdd',component: sealAdd},
//	其他
	{path:'/setUp',component: setUp},
//  个人中心
    {path:'/PersonCenter',component: PersonCenter},
    {path:'/example',component: example},
//  请假
    {path:'/leave',component: leave},
    {path:'/leaveAdd',component: leaveAdd},
    {path:'/myLeave',component: myLeave},
    {path:'/leaveDetail',component: leaveDetail},
//  异动
    {path:'/moveTab',component: moveTab},
    {path:'/writeMove',component: writeMove},
    {path:'/myMove',component: myMove},
    {path:'/moveDetail',component: moveDetail},
    
//  人力资源
    {path:'/zhaopinList', component: zhaopinList},
    {path:'/jobDetail',component: jobDetail},
    {path:'/writejobApply',component: writejobApply},
    {path:'/jobApply',component: jobApply},
    {path:'/moneyDetail',component: moneyDetail},
    {path:'/moneyList',component: moneyList},
    {path:'/zhaopinManage',component: zhaopinManage},
	{path:'/mianshiRecord',component: mianshiRecord},
	{path:'/shenqingDetail',component: shenqingDetail},
	{path:'/writeApply',component: writeApply},
	{path:'/mianshiDetail',component: mianshiDetail},
	{path:'/mianshiList',component: mianshiList},
	{path:'/piyue',component: piyue},
    {path:'/client',component: client},
    {path:'/hr',component: hr},
    {path:'/piyueDetail',component: piyueDetail},
    {path:'/kaoqingDetail',component: kaoqingDetail},
    {path:'/kaoqinList',component: kaoqinList},
    {path:'/apply',component: apply},
    {path:'/qiandao',component: qiandao},
//  测试界面
    {path:'/slideTable',component: slideTable},
    {path:'/alertCenter',component: alertCenter},
    {path:'/alertSearch',component: alertSearch},
    {path:'/alertRight',component: alertRight},
    {path:'/alert',component: alert},
    {path:'/muiSample',component: muiSample},
    {path:'/lookimg',component: lookimg},
    {path:'/mode_table',component: mode_table},
    {path:'/picker',component: picker},
    {path:'/dateTable',component: dateTable},
    {path:'/form',component: form},
    {path:'/tableList',component: tableList,},
    {path:'/template',component: template},
    {path:'/timeLine',component: timeLine},
    {path:'/formTable', component: formTable},
    {path:'/page', component: index},
    {path:'/actionsheet', component: actionsheet},
    {path:'/accordion', component: accordion},
    {path:'/badge', component: badge},
    {path:'/buttons', component: buttons},
    {path:'/numbutton', component: numbutton},
    {path:'/iconbutton', component: iconbutton},
    {path:'/loadbutton', component: loadbutton},
    {path:'/card', component: card},
    {path:'/checkbox', component: checkboxs},
    {path:'/dialog', component: dialog},
    {path:'/icons', component: icons},
    {path:'/iconsLight', component: iconsLight},
    {path:'/inputs', component: inputs},
    {path:'/MediaList', component: MediaList},
    {path:'/numbox', component: numbox},
    {path:'/slider', component: slider},
    {path:'/sliderTable', component: sliderTable},
    {path:'/sliderTitle', component: sliderTitle},
    {path:'/refresh', component: refresh},
    {path:'/tabView', component: tabView},
  ]
})

