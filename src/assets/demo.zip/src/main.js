// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import axios from "axios"	/* 异步请求*/
//Vue.use(axios)
//import ElementUI from 'element-ui';/*饿了么ui*/
//import 'element-ui/lib/theme-chalk/index.css';
//Vue.use(ElementUI);
import BaiduMap from 'vue-baidu-map'/*百度地图*/
Vue.use(BaiduMap, {
  // ak 是在百度地图开发者平台申请的密钥 详见 http://lbsyun.baidu.com/apiconsole/key */
  ak: 'izKslMWQG7sLmlaG4UjUV90Z'
})
import {BmlMarkerClusterer} from 'vue-baidu-map'/*百度第三方插件*/
Vue.component('bml-marker-cluster', BmlMarkerClusterer)

import preview from '../node_modules/vant/lib/image-preview';/*图片预览*/
import '../node_modules/vant/lib/image-preview/style';
Vue.use(preview)
import DropdownMenu from '../node_modules/vant/lib/dropdown-menu';/*下拉菜单*/
import DropdownItem from '../node_modules/vant/lib/dropdown-item';/*下拉菜单*/
import '../node_modules/vant/lib/dropdown-menu/style';
import '../node_modules/vant/lib/dropdown-item/style';
Vue.use(DropdownMenu)
Vue.use(DropdownItem);
import  NumberKeyboard  from '../node_modules/vant/lib/number-keyboard';/*数字键盘*/
import '../node_modules/vant/lib/number-keyboard/style';
Vue.use(NumberKeyboard);
import Uploader from '../node_modules/vant/lib/uploader';/*图片上传*/
import '../node_modules/vant/lib/uploader/style';
Vue.use(Uploader)
import  Popup  from '../node_modules/vant/lib/popup';/*选择器*/
import '../node_modules/vant/lib/popup/style';
Vue.use(Popup);
import Picker from '../node_modules/vant/lib/picker';/*选择器*/
import '../node_modules/vant/lib/picker/style';
Vue.use(Picker);
import router from './router'  /*建议将router引用放到最后*/



Vue.config.productionTip = false

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  components: { App },
  template: '<App/>'
})
