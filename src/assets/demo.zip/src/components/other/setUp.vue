<template>
	<div>
		<!--头部-->
		<header class="mui-bar mui-bar-nav back_title">
			<!--<a class="mui-action-back mui-icon mui-icon-left-nav mui-pull-left"></a>-->
			<h1 class="mui-title"><!--<img src="../assets/logo.png" class="logo"/>-->设置</h1>
		</header>
		<!--底部 选项卡-->
		<nav class="mui-bar mui-bar-tab">
			<router-link class="bottom-bar" to="/Home">
				<span class="mui-icon mui-icon-home"></span>
				<span class="mui-tab-label">首页</span>
			</router-link>
			<router-link class="bottom-bar" to="/newsTable">
				<span class="mui-icon mui-icon-email"><span class="mui-badge">9</span></span>
				<span class="mui-tab-label">消息</span>
			</router-link>
			<router-link class="bottom-bar active" to="/setUp">
				<span class="mui-icon mui-icon-gear"></span>
				<span class="mui-tab-label">设置</span>
			</router-link>
			<router-link class="bottom-bar" to="/PersonCenter">
				<span class="mui-icon mui-icon-contact"></span>
				<span class="mui-tab-label">个人中心</span>
			</router-link>
		</nav>
		<!--底部 选项卡结束-->
		<!--<div class="mui-content">
			<div id="slider" class="mui-slider mui-fullscreen">-->
			<!--头部选项卡-->
				<!--<div id="sliderSegmentedControl" class="mui-scroll-wrapper mui-slider-indicator mui-segmented-control mui-segmented-control-inverted">
					<div class="mui-scroll">
						<a class="mui-control-item mui-active" href="#item1mobile">
							推荐
						</a>
						<a class="mui-control-item" href="#item2mobile">
							热点
						</a>
						<a class="mui-control-item" href="#item3mobile">
							北京
						</a>
						<a class="mui-control-item" href="#item4mobile">
							社会
						</a>
						<a class="mui-control-item" href="#item5mobile">
							娱乐
						</a>
						<a class="mui-control-item" href="#item6mobile">
							科技
						</a>
					</div>
				</div>-->
			<!--头部选项卡结束-->
			
				<!--<div id="sliderProgressBar" class="mui-slider-progress-bar mui-col-xs-2"></div>-->
				
				<!--<div class="mui-slider-group listHeight">-->
					<!--第一个选项卡-->
					<!--<div id="item1mobile" class="mui-slider-item mui-control-content mui-active">-->
						<!--标题下面的select-->
						<!--<div class="select_condition">-->
							<!--<div>
								<div class="filter-box" id="filter-box">
									<div class="filter-text" >
										<input class="filter-title" type="text" readonly placeholder="pleace select" />
										<i class="icon icon-filter-arrow"></i>
									</div>
									<select name="filter">
										<option value="请选择" selected>请选择</option>
										<option value="new" disabled>最新的</option>
										<option value="未审核">未审核</option>
										<option value="正在审核">正在审核</option>
										<option value="已审核">已审核</option>
										<option value="已通过">已通过</option>
										<option value="111">111</option>
									</select>
								</div>
								<div class="filter-box" id="selectTow">
									<div class="filter-text" >
										<input class="filter-title" type="text" readonly placeholder="pleace select" />
										<i class="icon icon-filter-arrow"></i>
									</div>
									<select name="filter">
										<option value="请选择" selected>请选择</option>
										<option value="new" disabled>最新的</option>
										<option value="未审核">未审核</option>
										<option value="正在审核">正在审核</option>
										<option value="已审核">已审核</option>
										<option value="已通过">已通过</option>
										<option value="111">111</option>
									</select>
								</div>
								<div class="filter-box" id="selectThree">
									<div class="filter-text" >
										<input class="filter-title" type="text" readonly placeholder="pleace select" />
										<i class="icon icon-filter-arrow"></i>
									</div>
									<select name="filter">
										<option value="请选择" selected>请选择</option>
										<option value="new" disabled>最新的</option>
										<option value="未审核">未审核</option>
										<option value="正在审核">正在审核</option>
										<option value="已审核">已审核</option>
										<option value="已通过">已通过</option>
										<option value="111">111</option>
									</select>
								</div>-->
								<!--<div class="filter-box" id="selectFour">
									<div class="filter-text" >
										<input class="filter-title" type="text" readonly placeholder="pleace select" />
										<i class="icon icon-filter-arrow"></i>
									</div>
									<select name="filter">
										<option value="new" disabled>最新的</option>
										<option value="未审核">未审核</option>
										<option value="未通过" selected>未通过</option>
										<option value="正在审核">正在审核</option>
										<option value="已审核">已审核</option>
										<option value="已通过">已通过</option>
										<option value="111">111</option>
									</select>
								</div>-->
							<!--</div>-->
						<!--</div>-->
						<!--标题下面的select结束-->
						<!--列表内容-->
						<!--<div id="scroll1" class="mui-scroll-wrapper list_margin">
							<div class="mui-scroll">
								<ul class="mui-table-view">
									<li class="mui-table-view-cell">
										第1个选项卡子项-1
									</li>
									<li class="mui-table-view-cell">
										第1个选项卡子项-2
									</li>
									<li class="mui-table-view-cell">
										第1个选项卡子项-3
									</li>
									<li class="mui-table-view-cell">
										第1个选项卡子项-4
									</li>
									<li class="mui-table-view-cell">
										第1个选项卡子项-5
									</li>
									<li class="mui-table-view-cell">
										第1个选项卡子项-6
									</li>
									<li class="mui-table-view-cell">
										第1个选项卡子项-7
									</li>
									<li class="mui-table-view-cell">
										第1个选项卡子项-8
									</li>
									<li class="mui-table-view-cell">
										第1个选项卡子项-9
									</li>
									<li class="mui-table-view-cell">
										第1个选项卡子项-10
									</li>
									<li class="mui-table-view-cell">
										第1个选项卡子项-11
									</li>
									<li class="mui-table-view-cell">
										第1个选项卡子项-12
									</li>
									<li class="mui-table-view-cell">
										第1个选项卡子项-13
									</li>
									<li class="mui-table-view-cell">
										第1个选项卡子项-14
									</li>
									<li class="mui-table-view-cell">
										第1个选项卡子项-15
									</li>
									<li class="mui-table-view-cell">
										第1个选项卡子项-16
									</li>
									<li class="mui-table-view-cell">
										第1个选项卡子项-17
									</li>
									<li class="mui-table-view-cell">
										第1个选项卡子项-18
									</li>
									<li class="mui-table-view-cell">
										第1个选项卡子项-19
									</li>
									<li class="mui-table-view-cell">
										第1个选项卡子项-20
									</li>
								</ul>
							</div>
						</div>-->
						<!--列表内容结束-->
					<!--</div>-->
					<!--第一个选项卡结束-->
					<!--<div id="item2mobile" class="mui-slider-item mui-control-content">
						<div class="mui-scroll-wrapper list_margin">
							<div class="mui-scroll">
								<ul class="mui-table-view">
									<li class="mui-table-view-cell">
										第2个选项卡子项-1
									</li>
									<li class="mui-table-view-cell">
										第2个选项卡子项-2
									</li>
									<li class="mui-table-view-cell">
										第2个选项卡子项-3
									</li>
									<li class="mui-table-view-cell">
										第2个选项卡子项-4
									</li>
									<li class="mui-table-view-cell">
										第2个选项卡子项-5
									</li>
									<li class="mui-table-view-cell">
										第2个选项卡子项-6
									</li>
									<li class="mui-table-view-cell">
										第2个选项卡子项-7
									</li>
									<li class="mui-table-view-cell">
										第2个选项卡子项-8
									</li>
									<li class="mui-table-view-cell">
										第2个选项卡子项-9
									</li>
									<li class="mui-table-view-cell">
										第2个选项卡子项-10
									</li>
									<li class="mui-table-view-cell">
										第2个选项卡子项-11
									</li>
									<li class="mui-table-view-cell">
										第2个选项卡子项-12
									</li>
									<li class="mui-table-view-cell">
										第2个选项卡子项-13
									</li>
									<li class="mui-table-view-cell">
										第2个选项卡子项-14
									</li>
									<li class="mui-table-view-cell">
										第2个选项卡子项-15
									</li>
									<li class="mui-table-view-cell">
										第2个选项卡子项-16
									</li>
									<li class="mui-table-view-cell">
										第2个选项卡子项-17
									</li>
									<li class="mui-table-view-cell">
										第2个选项卡子项-18
									</li>
									<li class="mui-table-view-cell">
										第2个选项卡子项-19
									</li>
									<li class="mui-table-view-cell">
										第2个选项卡子项-20
									</li>
								</ul>
							</div>
						</div>
					</div>
					<div id="item3mobile" class="mui-slider-item mui-control-content">
						<div class="mui-scroll-wrapper list_margin">
							<div class="mui-scroll">
								<ul class="mui-table-view">
									<li class="mui-table-view-cell">
										第3个选项卡子项-1
									</li>
									<li class="mui-table-view-cell">
										第3个选项卡子项-2
									</li>
									<li class="mui-table-view-cell">
										第3个选项卡子项-3
									</li>
									<li class="mui-table-view-cell">
										第3个选项卡子项-4
									</li>
									<li class="mui-table-view-cell">
										第3个选项卡子项-5
									</li>
									<li class="mui-table-view-cell">
										第3个选项卡子项-6
									</li>
									<li class="mui-table-view-cell">
										第3个选项卡子项-7
									</li>
									<li class="mui-table-view-cell">
										第3个选项卡子项-8
									</li>
								</ul>
							</div>
						</div>
					</div>-->
					<!--<div id="item4mobile" class="mui-slider-item mui-control-content">
						<div class="mui-scroll-wrapper list_margin">
							<div class="mui-scroll">
								<ul class="mui-table-view">
									<li class="mui-table-view-cell">
										第4个选项卡子项-1
									</li>
									<li class="mui-table-view-cell">
										第4个选项卡子项-2
									</li>
								</ul>
							</div>
						</div>
					</div>-->
					<!--<div id="item5mobile" class="mui-slider-item mui-control-content">
						<div class="mui-scroll-wrapper list_margin">
							<div class="mui-scroll">
								<ul class="mui-table-view">
									<li class="mui-table-view-cell">
										第5个选项卡子项-1
									</li>
									<li class="mui-table-view-cell">
										第5个选项卡子项-2
									</li>
									<li class="mui-table-view-cell">
										第5个选项卡子项-3
									</li>
								</ul>
							</div>
						</div>
					</div>-->
					<!--<div id="item6mobile" class="mui-slider-item mui-control-content">
						<div class="mui-scroll-wrapper list_margin">
							<div class="mui-scroll">
								<ul class="mui-table-view">
									<li class="mui-table-view-cell">
										第6个选项卡子项-1
									</li>
									<li class="mui-table-view-cell">
										第6个选项卡子项-2
									</li>
									<li class="mui-table-view-cell">
										第6个选项卡子项-3
									</li>
									<li class="mui-table-view-cell">
										第6个选项卡子项-4
									</li>
									<li class="mui-table-view-cell">
										第6个选项卡子项-5
									</li>
								</ul>
							</div>
						</div>
					</div>-->
				</div>
			</div>
		</div>
	</div>
</template>

<script>
//	import '../../../static/utils/jquery.min.js'
	import '../../../static/utils/selectFilter.js'
	import '../../../static/css/selectFilter.css'
	import {pullRefresh} from '../../../static/utils/public.js'
	export default {
	data(){
		return{
			hello:'hello',
			hi:''
		}
	},
	mounted(){
		var that=this
		//这里是初始化
		$('#filter-box').selectFilter({
			callBack : function (val){
				//返回选择的值
				console.log(val+'-是返回的值')
				that.hello=val
			}
		});
		$('#selectTow').selectFilter({
			callBack : function (val){
				that.hi=val
			}
		});
		$('#selectThree').selectFilter({
			callBack : function (val){
				that.hello=val
			}
		});
//		$('#selectFour').selectFilter({
//			callBack : function (val){
//				that.hi=val
//			}
//		});
//		mui(".listHeight").on('tap',function(){  
//		   pullRefresh()
//		}) 
		pullRefresh()
		
		setTimeout(function(){
			var script=document.createElement('script'),
				app=document.querySelector("#app")
				script.appendChild(pullRefresh())
				app.appendChild(script)
			console.log('hi')
		},1200)
	},
}
</script>

<style>
	.select_condition{
	position: absolute;
    z-index: 222;
	}
	.listHeight{
		height: 530px;
	}
	.list_margin{
		margin-top: 40px;
		/*position: static;*/
	}
	.filter-list {
		position: fixed;
		width: 100%;
		top: 38px;
	}
	
	.item {
		width: 240px;
		height: 32px;
		margin: 100px auto;
	}
	
	.filter-box {
		display: inline-block;
		width: 24.2%;
	}
	
	.mui-control-content {
		background-color: white;
		min-height: 215px;
	}
	
	.mui-control-content .mui-loading {
		margin-top: 50px;
	}
	.mui-bar .mui-icon{
		padding: 0;
	}
	#sliderSegmentedControl .mui-active{
	position: relative;
	}
	#sliderSegmentedControl .mui-scroll .mui-active::after{
		content: '';
		position: absolute;
		left: 0;
		bottom: 0;
		width: 100%;
		height: 2px;
		background-color: #6596cc;
	}
	#sliderSegmentedControl .mui-scroll .mui-active{
		color: #6596cc;
	}
</style>