<template>
	<div>
		<header class="mui-bar mui-bar-nav">
			<a class="mui-action-back mui-icon mui-icon-left-nav mui-pull-left"></a>
			<h1 class="mui-title">选项卡切换+下拉刷新（div模式）</h1>
		</header>
		<!--<header class="mui-bar mui-bar-nav">-->
			<!--<router-link class="mui-icon mui-icon-left-nav mui-pull-left"></router-link>-->
			<!--<h1 class="mui-title"></h1>-->
		<!--</header>-->
		<div class="mui-content">
			<div id="slider" class="mui-slider mui-fullscreen">
				<div id="sliderSegmentedControl" class="mui-scroll-wrapper mui-slider-indicator mui-segmented-control mui-segmented-control-inverted">
					<div class="mui-scroll">
						<a class="mui-control-item mui-active" href="#item1mobile">
							推荐
						</a>
						<a class="mui-control-item" href="#item2mobile">
							热点
						</a>
						<a class="mui-control-item" href="#item3mobile">
							北京
						</a>
						<a class="mui-control-item" href="#item4mobile">
							社会
						</a>
						<a class="mui-control-item" href="#item5mobile">
							娱乐
						</a>
						<a class="mui-control-item" href="#item6mobile">
							科技
						</a>
					</div>
				</div>
				<div class="mui-slider-group">
					<div id="item1mobile" class="mui-slider-item mui-control-content mui-active">
						<div id="scroll1" class="mui-scroll-wrapper">
							<div class="mui-scroll">
								<ul class="mui-table-view">
									<li class="mui-table-view-cell">
										第1个选项卡子项-1
									</li>
									<li class="mui-table-view-cell">
										第1个选项卡子项-2
									</li>
									<li class="mui-table-view-cell">
										第1个选项卡子项-3
									</li>
									<li class="mui-table-view-cell">
										第1个选项卡子项-4
									</li>
									<li class="mui-table-view-cell">
										第1个选项卡子项-5
									</li>
									<li class="mui-table-view-cell">
										第1个选项卡子项-6
									</li>
									<li class="mui-table-view-cell">
										第1个选项卡子项-7
									</li>
									<li class="mui-table-view-cell">
										第1个选项卡子项-8
									</li>
									<li class="mui-table-view-cell">
										第1个选项卡子项-9
									</li>
									<li class="mui-table-view-cell">
										第1个选项卡子项-10
									</li>
									<li class="mui-table-view-cell">
										第1个选项卡子项-11
									</li>
									<li class="mui-table-view-cell">
										第1个选项卡子项-12
									</li>
									<li class="mui-table-view-cell">
										第1个选项卡子项-13
									</li>
									<li class="mui-table-view-cell">
										第1个选项卡子项-14
									</li>
									<li class="mui-table-view-cell">
										第1个选项卡子项-15
									</li>
									<li class="mui-table-view-cell">
										第1个选项卡子项-16
									</li>
									<li class="mui-table-view-cell">
										第1个选项卡子项-17
									</li>
									<li class="mui-table-view-cell">
										第1个选项卡子项-18
									</li>
									<li class="mui-table-view-cell">
										第1个选项卡子项-19
									</li>
									<li class="mui-table-view-cell">
										第1个选项卡子项-20
									</li>
								</ul>
							</div>
						</div>
					</div>
					<div id="item2mobile" class="mui-slider-item mui-control-content">
						<div class="mui-scroll-wrapper">
							<div class="mui-scroll">
								<ul class="mui-table-view">
									<li class="mui-table-view-cell">
										第2个选项卡子项-1
									</li>
									<li class="mui-table-view-cell">
										第2个选项卡子项-2
									</li>
									<li class="mui-table-view-cell">
										第2个选项卡子项-3
									</li>
									<li class="mui-table-view-cell">
										第2个选项卡子项-4
									</li>
									<li class="mui-table-view-cell">
										第2个选项卡子项-5
									</li>
									<li class="mui-table-view-cell">
										第2个选项卡子项-6
									</li>
									<li class="mui-table-view-cell">
										第2个选项卡子项-7
									</li>
									<li class="mui-table-view-cell">
										第2个选项卡子项-8
									</li>
									<li class="mui-table-view-cell">
										第2个选项卡子项-9
									</li>
									<li class="mui-table-view-cell">
										第2个选项卡子项-10
									</li>
									<li class="mui-table-view-cell">
										第2个选项卡子项-11
									</li>
									<li class="mui-table-view-cell">
										第2个选项卡子项-12
									</li>
									<li class="mui-table-view-cell">
										第2个选项卡子项-13
									</li>
									<li class="mui-table-view-cell">
										第2个选项卡子项-14
									</li>
									<li class="mui-table-view-cell">
										第2个选项卡子项-15
									</li>
									<li class="mui-table-view-cell">
										第2个选项卡子项-16
									</li>
									<li class="mui-table-view-cell">
										第2个选项卡子项-17
									</li>
									<li class="mui-table-view-cell">
										第2个选项卡子项-18
									</li>
									<li class="mui-table-view-cell">
										第2个选项卡子项-19
									</li>
									<li class="mui-table-view-cell">
										第2个选项卡子项-20
									</li>
								</ul>
							</div>
						</div>
					</div>
					<div id="item3mobile" class="mui-slider-item mui-control-content">
						<div class="mui-scroll-wrapper">
							<div class="mui-scroll">
								<ul class="mui-table-view">
									<li class="mui-table-view-cell">
										第3个选项卡子项-1
									</li>
									<li class="mui-table-view-cell">
										第3个选项卡子项-2
									</li>
									<li class="mui-table-view-cell">
										第3个选项卡子项-3
									</li>
									<li class="mui-table-view-cell">
										第3个选项卡子项-4
									</li>
									<li class="mui-table-view-cell">
										第3个选项卡子项-5
									</li>
									<li class="mui-table-view-cell">
										第3个选项卡子项-6
									</li>
									<li class="mui-table-view-cell">
										第3个选项卡子项-7
									</li>
									<li class="mui-table-view-cell">
										第3个选项卡子项-8
									</li>
									<li class="mui-table-view-cell">
										第3个选项卡子项-9
									</li>
									<li class="mui-table-view-cell">
										第3个选项卡子项-10
									</li>
									<li class="mui-table-view-cell">
										第3个选项卡子项-11
									</li>
									<li class="mui-table-view-cell">
										第3个选项卡子项-12
									</li>
									<li class="mui-table-view-cell">
										第3个选项卡子项-13
									</li>
									<li class="mui-table-view-cell">
										第3个选项卡子项-14
									</li>
									<li class="mui-table-view-cell">
										第3个选项卡子项-15
									</li>
									<li class="mui-table-view-cell">
										第3个选项卡子项-16
									</li>
									<li class="mui-table-view-cell">
										第3个选项卡子项-17
									</li>
									<li class="mui-table-view-cell">
										第3个选项卡子项-18
									</li>
									<li class="mui-table-view-cell">
										第3个选项卡子项-19
									</li>
									<li class="mui-table-view-cell">
										第3个选项卡子项-20
									</li>
								</ul>
							</div>
						</div>
					</div>
					<div id="item4mobile" class="mui-slider-item mui-control-content">
						<div class="mui-scroll-wrapper">
							<div class="mui-scroll">
								<ul class="mui-table-view">
									<li class="mui-table-view-cell">
										第4个选项卡子项-1
									</li>
									<li class="mui-table-view-cell">
										第4个选项卡子项-2
									</li>
									<li class="mui-table-view-cell">
										第4个选项卡子项-3
									</li>
									<li class="mui-table-view-cell">
										第4个选项卡子项-4
									</li>
									<li class="mui-table-view-cell">
										第4个选项卡子项-5
									</li>
									<li class="mui-table-view-cell">
										第4个选项卡子项-6
									</li>
									<li class="mui-table-view-cell">
										第4个选项卡子项-7
									</li>
									<li class="mui-table-view-cell">
										第4个选项卡子项-8
									</li>
									<li class="mui-table-view-cell">
										第4个选项卡子项-9
									</li>
									<li class="mui-table-view-cell">
										第4个选项卡子项-10
									</li>
									<li class="mui-table-view-cell">
										第4个选项卡子项-11
									</li>
									<li class="mui-table-view-cell">
										第4个选项卡子项-12
									</li>
									<li class="mui-table-view-cell">
										第4个选项卡子项-13
									</li>
									<li class="mui-table-view-cell">
										第4个选项卡子项-14
									</li>
									<li class="mui-table-view-cell">
										第4个选项卡子项-15
									</li>
									<li class="mui-table-view-cell">
										第4个选项卡子项-16
									</li>
									<li class="mui-table-view-cell">
										第4个选项卡子项-17
									</li>
									<li class="mui-table-view-cell">
										第4个选项卡子项-18
									</li>
									<li class="mui-table-view-cell">
										第4个选项卡子项-19
									</li>
									<li class="mui-table-view-cell">
										第4个选项卡子项-20
									</li>
								</ul>
							</div>
						</div>
					</div>
					<div id="item5mobile" class="mui-slider-item mui-control-content">
						<div class="mui-scroll-wrapper">
							<div class="mui-scroll">
								<ul class="mui-table-view">
									<li class="mui-table-view-cell">
										第5个选项卡子项-1
									</li>
									<li class="mui-table-view-cell">
										第5个选项卡子项-2
									</li>
									<li class="mui-table-view-cell">
										第5个选项卡子项-3
									</li>
									<li class="mui-table-view-cell">
										第5个选项卡子项-4
									</li>
									<li class="mui-table-view-cell">
										第5个选项卡子项-5
									</li>
									<li class="mui-table-view-cell">
										第5个选项卡子项-6
									</li>
									<li class="mui-table-view-cell">
										第5个选项卡子项-7
									</li>
									<li class="mui-table-view-cell">
										第5个选项卡子项-8
									</li>
									<li class="mui-table-view-cell">
										第5个选项卡子项-9
									</li>
									<li class="mui-table-view-cell">
										第5个选项卡子项-10
									</li>
									<li class="mui-table-view-cell">
										第5个选项卡子项-11
									</li>
									<li class="mui-table-view-cell">
										第5个选项卡子项-12
									</li>
									<li class="mui-table-view-cell">
										第5个选项卡子项-13
									</li>
									<li class="mui-table-view-cell">
										第5个选项卡子项-14
									</li>
									<li class="mui-table-view-cell">
										第5个选项卡子项-15
									</li>
									<li class="mui-table-view-cell">
										第5个选项卡子项-16
									</li>
									<li class="mui-table-view-cell">
										第5个选项卡子项-17
									</li>
									<li class="mui-table-view-cell">
										第5个选项卡子项-18
									</li>
									<li class="mui-table-view-cell">
										第5个选项卡子项-19
									</li>
									<li class="mui-table-view-cell">
										第5个选项卡子项-20
									</li>
								</ul>
							</div>
						</div>
					</div>
					<div id="item6mobile" class="mui-slider-item mui-control-content">
						<div class="mui-scroll-wrapper">
							<div class="mui-scroll">
								<ul class="mui-table-view">
									<li class="mui-table-view-cell">
										第6个选项卡子项-1
									</li>
									<li class="mui-table-view-cell">
										第6个选项卡子项-2
									</li>
									<li class="mui-table-view-cell">
										第6个选项卡子项-3
									</li>
									<li class="mui-table-view-cell">
										第6个选项卡子项-4
									</li>
									<li class="mui-table-view-cell">
										第6个选项卡子项-5
									</li>
									<li class="mui-table-view-cell">
										第6个选项卡子项-6
									</li>
									<li class="mui-table-view-cell">
										第6个选项卡子项-7
									</li>
									<li class="mui-table-view-cell">
										第6个选项卡子项-8
									</li>
									<li class="mui-table-view-cell">
										第6个选项卡子项-9
									</li>
									<li class="mui-table-view-cell">
										第6个选项卡子项-10
									</li>
									<li class="mui-table-view-cell">
										第6个选项卡子项-11
									</li>
									<li class="mui-table-view-cell">
										第6个选项卡子项-12
									</li>
									<li class="mui-table-view-cell">
										第6个选项卡子项-13
									</li>
									<li class="mui-table-view-cell">
										第6个选项卡子项-14
									</li>
									<li class="mui-table-view-cell">
										第6个选项卡子项-15
									</li>
									<li class="mui-table-view-cell">
										第6个选项卡子项-16
									</li>
									<li class="mui-table-view-cell">
										第6个选项卡子项-17
									</li>
									<li class="mui-table-view-cell">
										第6个选项卡子项-18
									</li>
									<li class="mui-table-view-cell">
										第6个选项卡子项-19
									</li>
									<li class="mui-table-view-cell">
										第6个选项卡子项-20
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
	import {pullRefresh} from '../../../static/utils/public.js';  
	
	export default {
	data() {
		return {
			dateday:'选择日期...',
		}
	},
	mounted(){
		pullRefresh()
	},
//	methods: {}
	}
</script>

<style>
	/** { touch-action: pan-y; }*/ 
	.mui-bar~.mui-content .mui-fullscreen {
		top: 44px;
		height: auto;
	}
	
	.mui-pull-top-tips {
		position: absolute;
		top: -20px;
		left: 50%;
		margin-left: -25px;
		width: 40px;
		height: 40px;
		border-radius: 100%;
		z-index: 1;
	}
	
	.mui-bar~.mui-pull-top-tips {
		top: 24px;
	}
	
	.mui-pull-top-wrapper {
		width: 42px;
		height: 42px;
		display: block;
		text-align: center;
		background-color: #efeff4;
		border: 1px solid #ddd;
		border-radius: 25px;
		background-clip: padding-box;
		box-shadow: 0 4px 10px #bbb;
		overflow: hidden;
	}
	
	.mui-pull-top-tips.mui-transitioning {
		-webkit-transition-duration: 200ms;
		transition-duration: 200ms;
	}
	
	.mui-pull-top-tips .mui-pull-loading {
		/*-webkit-backface-visibility: hidden;
		*-webkit-transition-duration: 400ms;
		*transition-duration: 400ms;
		* */
		margin: 0;
	}
	
	.mui-pull-top-wrapper .mui-icon,
	.mui-pull-top-wrapper .mui-spinner {
		margin-top: 7px;
	}
	
	.mui-pull-top-wrapper .mui-icon.mui-reverse {
		/*-webkit-transform: rotate(180deg) translateZ(0);*/
	}
	
	.mui-pull-bottom-tips {
		text-align: center;
		background-color: #efeff4;
		font-size: 15px;
		line-height: 40px;
		color: #777;
	}
	
	.mui-pull-top-canvas {
		overflow: hidden;
		background-color: #fafafa;
		border-radius: 40px;
		box-shadow: 0 4px 10px #bbb;
		width: 40px;
		height: 40px;
		margin: 0 auto;
	}
	
	.mui-pull-top-canvas canvas {
		width: 40px;
	}
	
	.mui-slider-indicator.mui-segmented-control {
		background-color: #efeff4;
	}

</style>