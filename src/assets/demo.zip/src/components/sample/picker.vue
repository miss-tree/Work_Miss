<template>
	<div>
		<header class="mui-bar mui-bar-nav">
			<a class="mui-action-back mui-icon mui-icon-left-nav mui-pull-left"></a>
			<h1 class="mui-title">dtpicker（日期时间选择器））</h1>
		</header>
		<!--<header class="mui-bar mui-bar-nav">-->
			<!--<router-link class="mui-icon mui-icon-left-nav mui-pull-left"></router-link>-->
			<!--<h1 class="mui-title"></h1>-->
		<!--</header>-->
		<div class="mui-content">
			<div class="mui-content-padded">
				<h5 class="mui-content-padded">常规示例</h5>
				<button id='demo1' data-options='{}' class="btn mui-btn mui-btn-block">选择日期时间 ...</button></br>
				<h5 class="mui-content-padded">设定年份区间</h5>
				<button id='demo2' data-options='{"type":"date","beginYear":2014,"endYear":2016}' class="btn mui-btn mui-btn-block">选择日期 ...</button></br>
				<h5 class="mui-content-padded">设定选中的时间</h5>
				<button id='demo3' data-options='{"value":"2015-10-10 10:10","beginYear":2010,"endYear":2020}' class="btn mui-btn mui-btn-block">选择日期时间 ...</button></br>
				<h5 class="mui-content-padded">指定类型</h5>
				<button id='demo4' data-options='{"type":"date"}' class="btn mui-btn mui-btn-block">选择日期 ...</button></br>
				<button id='demo5' data-options='{"type":"time"}' class="btn mui-btn mui-btn-block">选择时间 ...</button></br>
				<button id='demo6' data-options='{"type":"month"}' class="btn mui-btn mui-btn-block">选择月份 ...</button></br>
				<h5 class="mui-content-padded">自定义数据</h5>
				<button id='demo7' data-options='{"type":"hour","customData":{"h":[{"text":"上午","value":"上午"},{"text":"下午","value":"下午"},{"text":"晚上","value":"晚上"}]},"labels":["年", "月", "日", "时段", "分"]}' class="btn mui-btn mui-btn-block">选择时段 ...</button>
				</br>
				<div id='result' class="ui-alert"></div>
			</div>
		</div>
	</div>
</template>

<script>
//	import mui from 'mui';  
//	require('../../static/utils/mui.picker.js');  
//	require('../../static/utils/mui.poppicker.js'); 
	
//	import poppicker from '../../static/utils/mui.poppicker.js'
	export default {
	data() {
		return {
			dateday:'选择日期...',
		}
	},
	mounted(){
		(function($) {
				$.init();
				var result = $('#result')[0];
				var btns = $('.btn');
				btns.each(function(i, btn) {
					btn.addEventListener('tap', function() {
						var _self = this;
						if(_self.picker) {
							_self.picker.show(function(rs) {
								result.innerText = '选择结果: ' + rs.text;
								_self.picker.dispose();
								_self.picker = null;
							});
						} else {
							var optionsJson = this.getAttribute('data-options') || '{}';
							var options = JSON.parse(optionsJson);
							var id = this.getAttribute('id');
							/*
							 * 首次显示时实例化组件
							 * 示例为了简洁，将 options 放在了按钮的 dom 上
							 * 也可以直接通过代码声明 optinos 用于实例化 DtPicker
							 */
							_self.picker = new $.DtPicker(options);
							_self.picker.show(function(rs) {
								/*
								 * rs.value 拼合后的 value
								 * rs.text 拼合后的 text
								 * rs.y 年，可以通过 rs.y.vaue 和 rs.y.text 获取值和文本
								 * rs.m 月，用法同年
								 * rs.d 日，用法同年
								 * rs.h 时，用法同年
								 * rs.i 分（minutes 的第二个字母），用法同年
								 */
								result.innerText = '选择结果: ' + rs.text;
								/* 
								 * 返回 false 可以阻止选择框的关闭
								 * return false;
								 */
								/*
								 * 释放组件资源，释放后将将不能再操作组件
								 * 通常情况下，不需要示放组件，new DtPicker(options) 后，可以一直使用。
								 * 当前示例，因为内容较多，如不进行资原释放，在某些设备上会较慢。
								 * 所以每次用完便立即调用 dispose 进行释放，下次用时再创建新实例。
								 */
								_self.picker.dispose();
								_self.picker = null;
							});
						}

					}, false);
				});
			})(mui);
	},
//	methods: {}
		}
</script>

<style>
</style>