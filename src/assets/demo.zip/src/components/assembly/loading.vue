<template>
	<div>
		<div class="mongolia"></div>
		<div class="loading">
			<div class="loadingAlert">
				<img src="../../../static/assets/loading.gif" />
			</div>
		</div>
	</div>
</template>

<!--加载组件，组件外部只要加个v-show控制就好了-->
<script>
	export default {

	}
</script>

<style scoped>
</style>