<template>
	<div>
		<header class="mui-bar mui-bar-nav">
		    <a  class="mui-action-back mui-icon mui-icon-left-nav mui-pull-left"></a>
		    <h1 class="mui-title">签到</h1>
		</header>
		<div class="bar-ge"></div>
		<div class="margin-t">
			<div class="padding-lr padding-tb">
				<div class="hang">
					<label class="text-justify">药店名称<span class="span-justify"></span></label>
					<span class="margin-lr">好邻居大药房</span>
				</div>
				<div class="hang">
					<label class="text-justify">活动名称<span class="span-justify"></span></label>
					<span class="margin-lr">口罩</span>
				</div>
				<div class="hang">
					<label class="text-justify">上传时间<span class="span-justify"></span></label>
					<span class="margin-lr">2018-11-02 15：26</span>
				</div>
			</div>
		</div>
		<div class="margin-t">
			<div class="detail-img">
				<img src="../../../static/assets/pic-98465.jpg"/>
			</div>
			<div class="detail-img">
				<img src="../../../static/assets/pic-98465.jpg"/>
			</div>
		</div>
	</div>
</template>

<script>
	export default{
		data(){
			return{
			}
		},
		methods:{
//			jump(){
//				this.$router.go(-1)
//			}
		}
	}
</script>

<style>
</style>