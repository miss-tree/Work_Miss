<template>
	<div>
		<header class="mui-bar mui-bar-nav">
			<a class="mui-action-back mui-icon mui-icon-left-nav mui-pull-left"></a>		    
		    <h1 class="mui-title">面试详情</h1>
		</header>
		<div class="mui-content">
			<div class="margin-t">
				<div class="padding-lr padding-tb">
					<div class="hang">
						<label class="text-justify">面试HR<span class="span-justify"></span></label>
						<span class="margin-lr">XXX</span>
					</div>
					<div class="hang">
						<label class="text-justify">应聘职位<span class="span-justify"></span></label>
						<span class="margin-lr">服务专员</span>
					</div>
					<div class="hang">
						<label class="text-justify">面试时间<span class="span-justify"></span></label>
						<span class="margin-lr">2018-10-22</span>
					</div>
					<div class="hang">
						<label class="text-justify">联系电话<span class="span-justify"></span></label>
						<span class="margin-lr" style="color: red;">159xxxxxxxx</span>
					</div>
					<div class="hang">
						<label class="text-justify">状态<span class="span-justify"></span></label>
						<span class="margin-lr">复试</span>
					</div>
					<div class="hang">
						备注
					</div>
					<div class="hang">
						<p style="text-indent: 2em;">
							该面试者，成绩及表现优异，优先录取
						</p>
					</div>
				</div>
					<div class="padding-lr margin-t">
						附件上传
					</div>
					<div class="margin-t">
						<div class="detail-img">
							<img src="../../../static/assets/pic-516.png"/>
						</div>
						<div class="detail-img">
							<img src="../../../static/assets/pic-98465.jpg"/>
						</div>
					</div>
			</div>
		</div>
	</div>
</template>

<script>
	
</script>

<style>
</style>