<template>
	<div>
		<div class="dingwei" @click="changeup()">
			<img src="../../static/assets/pic-01_03.png" alt=""  :class="{playnone:trans}"/>
		</div>
		<div class="donghua">
			<div class="dhcontain " :class="{ transup: trans }">
				<router-link to="/Home">
					<div class="dh-img">
						<img src="../../static/assets/pic-04_03.png"/>
					</div>
				</router-link>	
				<div class="dh-img" @click="change()">
					<img src="../../static/assets/pic-03_03.png"/>
				</div>
				<div class="dh-img" @click="changeup()" >
					<img src="../../static/assets/pic-02_03.png"/>
				</div>
			</div>
		</div>
		<div class="search" :class="{playnone:ss}">
			<div class="bar-ge"></div>
			<div class="search-tion">
				查询条件
			</div>
			<div class="search-date">
				<div>
					<span>开始时间</span>
					<!--<datepick v-on:updata='dateUpdate'></datepick>-->
					<input type="text" id='demo5' data-options='{"type":"date"}' class="btn mui-btn mui-btn-block form_row_right"
			    				placeholder="选择日期 ..." v-model="item.endTime">
				</div>
				<div class="margin-t">
					<span>结束时间</span>
					<!--<button id='demo1' class="btn mui-btn mui-btn-block">
						选择日期 ...
					</button>-->
					<datepick v-on:updata='timeUpdate'></datepick>
				</div>
			</div>
		</div>	
	</div>
</template>

<script>
	import datepick from "./assembly/datepick" 
	import {selectTime} from "../../static/utils/public.js"
	export default {
	data() {
		return {
			trans: false, //控制动画
//				snone:true,
			ss: true,
			startDate: '选择日期 ...',
			endDate: '选择日期 ...'
		}
	},
	//		components:{
	//			datepick,
	//		},
	mounted() {
		selectTime()
	},
	methods: {
		dateUpdate() {
			this.startDate = v
		},

		timeUpdate(v) {

			this.endDate = v
		},
		changeup(e) {
			this.trans = !this.trans
			this.ss = this.ss
		},
		change() {
			this.ss = !this.ss
		}
	}
}</script>

<style lang="scss">

</style>